Hello (INSERT TA NAME)
Hope you are not having too much difficulty running these student projects.
Here is my guide for setting up my database environment.
I also shared my setup file with other students to hopefully make things easier for you.
Enjoy.

TO POPULATE THE DATABASE:
Open the command line in administrator mode,
Nagivate to this directory.
Run the command "db2cmd" which should open a new command line terminal.
Then type out "createDatabase.bat" and hit enter.
It should slowly create everything.

SETUP CONFIG.PHP
Open config.php
declare:
$database to be the specified database name,
$user to be the administrator database user account,
$pass to be the administrator database password
userAccount to be the systems currently logged in user account. This you may be able to leave blank, if it doesn't work, then set with appropiate information.

Enjoy.

