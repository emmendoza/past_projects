<?php
$database = "cs174";
$user = "db2admin";
$pass = "password";
const userAccount = "";// you may be able to just leave this blank, if it complains, then set with the currently logged in user account name
?>